using UnityEngine;

public class GreenBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject greenBall;
    public Rigidbody2D my_rb;
  

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    { //Begin start function 
         Debug.Log("Oh. Hello there. This is the GreenBallScript's Start ;P ");
        //jumpForce = 5;

    }// end start function

    // Update is called once per frame
    void Update()
    {
   
        if (Input.GetKey(KeyCode.LeftArrow)) {

           Debug.Log("leftarrow key pressed");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);

        }

         if (Input.GetKey(KeyCode.RightArrow)) {

           Debug.Log("right arrow key pressed");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);

        }

        if ((Input.GetKey(KeyCode.Space)) || (Input.GetKey(KeyCode.UpArrow))) {

           Debug.Log("uparrow key pressed");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

    

        }
    }
}





