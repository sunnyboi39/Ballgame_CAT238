using UnityEngine;

public class starcollide : MonoBehaviour
{
    public Collider2D my_col;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Collide()
    {
        if (my_col.gameObject.tag == "Player")
        {
            Debug.Log("collision detected: " + my_col.gameObject.name);
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Collide();
    }
}
