using UnityEngine;

public class empty : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject pinkBall;
    public Rigidbody2D my_rb;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("move pinkball script");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            Debug.Log("A key pressed");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);

        }

        if (Input.GetKey(KeyCode.D))
        {

            Debug.Log("D key pressed");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);

        }
        if (Input.GetKey(KeyCode.W))
        {

            Debug.Log("w key pressed");
            Jump();

        }
    }
    void Jump()
    {
        Debug.Log("jump function");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

    }
}
