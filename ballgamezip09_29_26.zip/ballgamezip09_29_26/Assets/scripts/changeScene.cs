using UnityEngine;
using UnityEngine.SceneManagement;

public class changeScene : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.Alpha6)){
            sceneChange(1);//switch to second scene whne you press 6
        }
        if (Input.GetKey(KeyCode.Alpha7))
        {
            sceneChange(0);//switch to second scene whne you press 6
        }

    }
    void sceneChange(int sceneNum)
    {
        SceneManager.LoadScene(sceneNum);
    }
}
