using UnityEngine;

public class camera : MonoBehaviour
{
    public Transform followObj; // Transform: 
    private void FixedUpdate() //
    {
        Vector3 currentPosition = transform.position;
        // a transform position
        currentPosition.x = Mathf.Lerp(currentPosition.x, followObj.position.x,.5f);
        currentPosition.z = -1;
        transform.position = currentPosition;
        //Debug.Log("transform position: "+ transform.position);
    }
}
