using UnityEngine;

public class collideDetection : MonoBehaviour
{
    //public Collider2D my_col;
    void OnCollisionEnter2D(Collision2D collider)//does not need to be manually called
    {
        Debug.Log("collide function called");
        //Debug.Log("collision detected: ");
        if (collider.gameObject.CompareTag("star")|| collider.gameObject.CompareTag("pinkball"))
        {
            if (collider.otherCollider.gameObject.CompareTag("Player"))
            {
                Debug.Log("collision detected: " + collider.gameObject.name + " with " + collider.otherCollider.gameObject.name);

            }
        }
        
    }

    
}
